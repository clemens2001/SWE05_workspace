import { IsbnValidatorDirective } from './isbn-validator.directive';

describe('IsbnValidatorDirective', () => {
  it('should create an instance', () => {
    const directive = new IsbnValidatorDirective();
    expect(directive).toBeTruthy();
  });
});
