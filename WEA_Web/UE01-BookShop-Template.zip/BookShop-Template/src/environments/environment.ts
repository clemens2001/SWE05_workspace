export const environment = {
    production: false,
    server: 'http://localhost:3200/bookshop-rest-service/api',
    images: 'http://localhost:3200/'
  };