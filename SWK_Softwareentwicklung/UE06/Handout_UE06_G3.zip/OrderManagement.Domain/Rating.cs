﻿namespace OrderManagement.Domain;

public enum Rating
{
  A,
  B,
  C
}