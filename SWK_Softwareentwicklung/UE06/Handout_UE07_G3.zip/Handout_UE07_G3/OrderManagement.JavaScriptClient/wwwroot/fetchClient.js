const ORDER_MANAGEMENT_BASE_URI = "https://localhost:7148";
function fetchCustomerById(id) {
    if (!id)
        throw new Error('ID must not be empty');
    return fetch(`${ORDER_MANAGEMENT_BASE_URI}/api/customers/${id}`, {
        method: "GET",
        headers: { 'Accept': 'application/json' }
    })
        .then(response => {
        if (!response.ok)
            throw new Error(`Failed with status code ${response.status}`);
        return response.json().then(data => {
            return Promise.resolve(data);
        });
    });
}
async function fetchCustomerByIdAsync(id) {
    if (!id)
        throw new Error('ID must not be empty');
    const response = await fetch(`${ORDER_MANAGEMENT_BASE_URI}/api/customers/${id}`, {
        method: "GET",
        headers: { 'Accept': 'application/json' },
    });
    if (response.status !== 200)
        throw new Error(`Failed with status code ${response.status}`);
    return await response.json();
}
//# sourceMappingURL=fetchClient.js.map