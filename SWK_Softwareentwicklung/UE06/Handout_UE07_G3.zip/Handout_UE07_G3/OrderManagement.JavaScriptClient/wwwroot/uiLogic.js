const btnFetchCustomer = document.getElementById("btnFetchCustomer");
const txtCustomerId = document.getElementById("txtCustomerId");
const txtName = document.getElementById("txtName");
const txtZipCode = document.getElementById("txtZipCode");
const txtCity = document.getElementById("txtCity");
const txtRating = document.getElementById("txtRating");
const errorCustomerId = document.getElementById("errorCustomerId");
function displayCustomer(customer) {
    txtName.value = customer.name;
    txtZipCode.value = customer.zipCode.toString();
    txtCity.value = customer.city;
    txtRating.value = customer.rating;
}
function setValidationError(inputElement, errorMessage) {
    inputElement.classList.add("is-invalid");
    errorCustomerId.innerHTML = errorMessage;
    txtName.value = "";
    txtZipCode.value = "";
    txtCity.value = "";
    txtRating.value = "";
}
function resetValidationError(inputElement) {
    inputElement.classList.remove("is-invalid");
    errorCustomerId.innerHTML = "";
}
async function onFetchButtonClicked() {
    let customerId = txtCustomerId.value;
    resetValidationError(txtCustomerId);
    try {
        const customer = await fetchCustomerByIdAsync(customerId);
        displayCustomer(customer);
    }
    catch (error) {
        setValidationError(txtCustomerId, error?.message ?? "Unexpected exception");
    }
}
window.onload = () => btnFetchCustomer.onclick = onFetchButtonClicked;
//# sourceMappingURL=uiLogic.js.map